const express = require("express");
const router = express.Router();

const setting_tamu = require("../controllers/setting_tamu");

router.get("/setting/tamu", setting_tamu.tampil);
router.get("/setting/tamu/:id_setting_tamu", setting_tamu.cari);
router.post("/setting/tamu", setting_tamu.simpan);
router.put("/setting/tamu/:id_setting_tamu", setting_tamu.edit);

module.exports = router;