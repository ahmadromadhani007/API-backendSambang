const express = require("express");
const router = express.Router();
router.use(require("./setting_pertemuan"));
router.use(require("./setting_tamu"));

module.exports = router;
