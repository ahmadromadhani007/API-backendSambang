module.exports = (sequelize, DataTypes) => {
    const setting_tamu = sequelize.define('setting_tamu', {
        id_setting_tamu  : {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false
        },
        jml_tamu:{
            type: DataTypes.STRING,
            allowNull: false
        },
        status:{
            type: DataTypes.ENUM('y', 't'),
            allowNull: false
        },
    }, {
        tableName: 'tb_setting_tamu'
    })
    return setting_tamu;
};